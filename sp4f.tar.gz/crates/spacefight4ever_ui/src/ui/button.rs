/// part of what a button is, the other part is the button component
#[derive(PartialEq, Eq, Clone, Copy)]
pub enum ButtonState {
    Normal,
    Hovered,
    Pressed,
    Disabled,
}

impl ButtonState {
    pub fn index(self) -> usize {
        match self {
            ButtonState::Normal => 0,
            ButtonState::Hovered => 1,
            ButtonState::Pressed => 2,
            ButtonState::Disabled => 3,
        }
    }
}
// impl Index<ButtonState> for ButtonSkins {
//     type Output = usize;

//     fn index(&self, state: ButtonState) -> &Self::Output {
//         match state {
//             ButtonState::Normal => 0,
//             ButtonState::Hovered => 1,
//             ButtonState::Pressed => 2,
//             ButtonState::Disabled => 3,
//         }
//     }
// }