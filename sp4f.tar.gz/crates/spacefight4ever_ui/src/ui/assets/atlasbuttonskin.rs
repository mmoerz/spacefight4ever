use std::ops::{Index, IndexMut};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use bevy::{
    asset::{io::Reader, AssetLoader, LoadContext},
    prelude::*,
    reflect::TypePath,
};

use crate::ui::button::ButtonState;

/// Intermediate struct for deserializing button skin data from disk
#[derive(TypePath, Debug, Deserialize, Serialize)]
pub struct DiskButtonSkin {
    pub image_name: String, // path to the texture atlas
    pub mapping: [usize; 4], // Normal, Hovered, Pressed, Disabled
    pub tile_size: [u32; 2],
    pub rows: u32,
    pub cols: u32,
}

/// Runtime struct representing a button skin, 
/// which includes handles to the texture and atlas layout for
/// different button states.
#[derive(Asset, TypePath, Debug, Clone)]
pub struct ButtonSkin {
    pub atlas: Handle<TextureAtlasLayout>,
    pub image: Handle<Image>,
    pub mapping: [usize; 4], // Normal, Hovered, Pressed, Disabled
}

impl Index<ButtonState> for ButtonSkin {
    type Output = usize;

    /// Get the atlas index for a given button state
    /// This allows us to easily switch button appearances based on interaction state
    fn index(&self, state: ButtonState) -> &Self::Output {
        &self.mapping[state.index()]
    }
}

impl IndexMut<ButtonState> for ButtonSkin {
    /// Set the atlas index for a given button state
    fn index_mut(&mut self, state: ButtonState) -> &mut Self::Output {
        &mut self.mapping[state.index()]
    }
}

/// custom asset loader for ButtonSkin, 
/// which reads from a RON file and loads the associated texture
#[derive(Default, TypePath)]
struct ButtonSkinLoader;

/// Possible errors that can be produced by [`CustomAssetLoader`]
#[non_exhaustive]
#[derive(Debug, Error)]
enum ButtonSkinLoaderError {
    /// An [IO](std::io) Error
    #[error("Could not load asset: {0}")]
    Io(#[from] std::io::Error),
    /// A [RON](ron) Error
    #[error("Could not parse RON: {0}")]
    RonSpannedError(#[from] ron::error::SpannedError),
}

/// Implementation of the custom asset loader for `ButtonSkin`
/// This loader reads a RON file that specifies the texture atlas and mapping for button states,
/// and then loads the associated texture as a Bevy asset.
impl AssetLoader for ButtonSkinLoader {
    type Asset = ButtonSkin;
    type Settings = ();
    type Error = ButtonSkinLoaderError;
    async fn load(
        &self,
        reader: &mut dyn Reader,
        _settings: &(),
        load_context: &mut LoadContext<'_>,
    ) -> Result<Self::Asset, Self::Error> {
        let mut bytes = Vec::new();
        reader.read_to_end(&mut bytes).await?;
        
        let disk: DiskButtonSkin = ron::de::from_bytes(&bytes)?;

        // 👇 Load image dependency
        let image_handle: Handle<Image> =
            load_context.load(disk.image_name.clone());

        // 👇 Create atlas layout
        // yeah this really needs to be separate from the image because
        // ImageNode needs both the image and the atlas layout
        let layout = TextureAtlasLayout::from_grid(
            UVec2::new(disk.tile_size[0], disk.tile_size[1]),
            disk.cols,
            disk.rows,
            None,
            None,
        );

        // 👇 Register layout as sub-asset
        let layout_handle = load_context.add_labeled_asset(
            "layout".into(),
            layout,
        );
        
        // 👇 Return runtime asset
        Ok(ButtonSkin {
            atlas: layout_handle,
            image: image_handle,
            mapping: disk.mapping,
        })
    }

    fn extensions(&self) -> &[&str] {
        &["ron"]
    }
}
